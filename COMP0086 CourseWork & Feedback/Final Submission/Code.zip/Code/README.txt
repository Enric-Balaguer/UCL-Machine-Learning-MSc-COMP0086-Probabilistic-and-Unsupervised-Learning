- Regarding my code:
	I submit my code in jupyter notebook format. 
	Please note I have used VS Code for my code (as recommended in other modules).
	If for some reason that poses problems, I am also attaching .pdf files for all my code.
	Hopefully, everything works well and you can see everything works by just pressing "Run All"

- Regarding my report:
	I attach a single pdf file of my report in the .zip file.
